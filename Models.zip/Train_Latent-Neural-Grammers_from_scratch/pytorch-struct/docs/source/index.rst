=================
PyTorch-Struct
=================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   README
   model
   networks
   semiring
   refs





Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
